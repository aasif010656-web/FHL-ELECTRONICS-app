.class public final enum Lcom/getcapacitor/ServerPath$PathType;
.super Ljava/lang/Enum;
.source "ServerPath.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/getcapacitor/ServerPath;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "PathType"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/getcapacitor/ServerPath$PathType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/getcapacitor/ServerPath$PathType;

.field public static final enum ASSET_PATH:Lcom/getcapacitor/ServerPath$PathType;

.field public static final enum BASE_PATH:Lcom/getcapacitor/ServerPath$PathType;


# direct methods
.method private static synthetic $values()[Lcom/getcapacitor/ServerPath$PathType;
    .locals 3

    .line 5
    const/4 v0, 0x2

    new-array v0, v0, [Lcom/getcapacitor/ServerPath$PathType;

    const/4 v1, 0x0

    sget-object v2, Lcom/getcapacitor/ServerPath$PathType;->BASE_PATH:Lcom/getcapacitor/ServerPath$PathType;

    aput-object v2, v0, v1

    const/4 v1, 0x1

    sget-object v2, Lcom/getcapacitor/ServerPath$PathType;->ASSET_PATH:Lcom/getcapacitor/ServerPath$PathType;

    aput-object v2, v0, v1

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 6
    new-instance v0, Lcom/getcapacitor/ServerPath$PathType;

    const-string v1, "BASE_PATH"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/getcapacitor/ServerPath$PathType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/getcapacitor/ServerPath$PathType;->BASE_PATH:Lcom/getcapacitor/ServerPath$PathType;

    .line 7
    new-instance v0, Lcom/getcapacitor/ServerPath$PathType;

    const-string v1, "ASSET_PATH"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/getcapacitor/ServerPath$PathType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/getcapacitor/ServerPath$PathType;->ASSET_PATH:Lcom/getcapacitor/ServerPath$PathType;

    .line 5
    invoke-static {}, Lcom/getcapacitor/ServerPath$PathType;->$values()[Lcom/getcapacitor/ServerPath$PathType;

    move-result-object v0

    sput-object v0, Lcom/getcapacitor/ServerPath$PathType;->$VALUES:[Lcom/getcapacitor/ServerPath$PathType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 5
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/getcapacitor/ServerPath$PathType;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .line 5
    const-class v0, Lcom/getcapacitor/ServerPath$PathType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/getcapacitor/ServerPath$PathType;

    return-object v0
.end method

.method public static values()[Lcom/getcapacitor/ServerPath$PathType;
    .locals 1

    .line 5
    sget-object v0, Lcom/getcapacitor/ServerPath$PathType;->$VALUES:[Lcom/getcapacitor/ServerPath$PathType;

    invoke-virtual {v0}, [Lcom/getcapacitor/ServerPath$PathType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/getcapacitor/ServerPath$PathType;

    return-object v0
.end method
